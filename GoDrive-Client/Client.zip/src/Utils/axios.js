import axios from 'axios';

// Backend API configuration
const api = axios.create({
  baseURL: 'http://localhost:5000/api', // Replace with your server's base URL
  headers: {
    'Content-Type': 'application/json',
  },
});
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);
export default api;