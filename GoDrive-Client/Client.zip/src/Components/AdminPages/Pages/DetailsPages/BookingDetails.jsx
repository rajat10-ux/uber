import React from 'react'

const BookingDetails = () => {
  return (
    <div>
      BookingDetails
      BookingDetails
    </div>
  )
}

export default BookingDetails
