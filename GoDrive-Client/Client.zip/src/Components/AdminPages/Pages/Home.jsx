import React from 'react'

const Home = () => {
  return (
    <div>
      Dashboard
    </div>
  )
}

export default Home
