import React from 'react'
 const Driverdetails = () => {
  return (
    <div>driverdetails</div>
  )
}

export default Driverdetails;